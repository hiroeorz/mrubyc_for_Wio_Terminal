#ifndef SNIPPET_HDR_CLIENT_H
#define SNIPPET_HDR_CLIENT_H

#ifdef __cplusplus
extern "C" {
#endif

void client_connect(void);

#ifdef __cplusplus
}
#endif

#endif
