#ifndef SNIPPET_HDR_NETCONN_SERVER_1THREAD_H
#define SNIPPET_HDR_NETCONN_SERVER_1THREAD_H

#ifdef __cplusplus
extern "C" {
#endif

void netconn_server_1thread_thread(void* arg);

#ifdef __cplusplus
}
#endif

#endif
