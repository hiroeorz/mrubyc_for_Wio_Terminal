#ifndef SNIPPET_HDR_HTTP_SERVER_H
#define SNIPPET_HDR_HTTP_SERVER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "esp/esp.h"

espr_t  http_server_start(void);

#ifdef __cplusplus
}
#endif

#endif
