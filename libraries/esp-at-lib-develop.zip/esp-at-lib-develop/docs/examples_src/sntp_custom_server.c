/* Set custom NTP servers. You may apply up to 3 servers, all are optional */
esp_sntp_configure(1, 1, "server1.myntp.com", "server2.myntp.com", "server3.myntp.com", NULL, NULL, 1);