.. _api_esp_utils:

Utilities
=========

Utility functions for various cases.
These function are used across entire middleware and can also be used by application.

.. doxygengroup:: ESP_UTILS