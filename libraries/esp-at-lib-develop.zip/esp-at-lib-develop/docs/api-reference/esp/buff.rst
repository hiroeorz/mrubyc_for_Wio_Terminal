.. _api_esp_buff:

Ring buffer
===========

.. doxygengroup:: ESP_BUFF