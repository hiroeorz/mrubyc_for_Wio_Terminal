.. _api_esp_wps:

Wi-Fi Protected Setup
=====================

.. doxygengroup:: ESP_WPS