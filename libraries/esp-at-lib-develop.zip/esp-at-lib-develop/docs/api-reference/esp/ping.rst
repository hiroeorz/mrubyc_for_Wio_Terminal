.. _api_esp_ping:

Ping support
============

.. doxygengroup:: ESP_PING