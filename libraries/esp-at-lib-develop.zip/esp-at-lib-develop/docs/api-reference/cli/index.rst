.. _api_cli:

Command line interface
======================

.. toctree::
	:maxdepth: 2
	:glob:

	*

.. doxygengroup:: CLI