.. _api_app_mqtt_client:

MQTT Client
===========

MQTT client v3.1.1 implementation, based on callback (non-netconn) connection API.

.. literalinclude:: ../../../snippets/mqtt_client.c
    :language: c
    :linenos:
    :caption: MQTT application example code

.. doxygengroup:: ESP_APP_MQTT_CLIENT
.. doxygengroup:: ESP_APP_MQTT_CLIENT_EVT