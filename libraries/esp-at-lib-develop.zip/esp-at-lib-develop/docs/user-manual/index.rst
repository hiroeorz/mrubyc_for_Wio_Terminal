.. _um:

User manual
===========

.. toctree::
    :maxdepth: 2

    overview
    architecture
    inter-thread-comm
    events-cb-fn
    blocking-nonblocking
    porting-guide
    